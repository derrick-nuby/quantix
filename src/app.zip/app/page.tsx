import TableMain from '@/components/table/TableMain';
import React from 'react';

export default function page() {
  return (
    <TableMain />
  );
}
